export const VIEW = 'VIEW'
export const SET = 'SET'